<?php  
//membuat koneksi ke database  
$host = 'localhost';  
  $user = 'root';        
  $password = 'BANDUNG123';        
  $database = 'sbp';    
      
  $konek_db = mysqli_connect($host, $user, $password, $database);      
?>