# Farmilify
Farmilify ! System Information that helps on agricultural aspect, such as farming, and others.

Developed by : 

Muhammad Felmi <br>
Mochammad Rizky <br>
Tresna R
